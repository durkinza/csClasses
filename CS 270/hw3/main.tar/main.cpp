#include <stdio.h>
#include "table.h"
int main(){
	printf("A table of values follows.\n");
	table(0.0, 10.0, 1.0);
	return 0;
}
