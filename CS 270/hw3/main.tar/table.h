#ifndef TABLEFILE
#define TABLEFILE
int table(double start, double end, double step);
#endif
