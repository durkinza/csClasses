#ifndef FUNCSFILE
#define FUNCSFILE
double f(double x);
double g(double x);
#endif
