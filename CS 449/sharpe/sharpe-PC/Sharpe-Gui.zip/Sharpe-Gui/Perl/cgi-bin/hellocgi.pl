#!perl

# simple hello world cgi script
print "Content-type: text/html\n\n";
print "<html><body>\n";
print "<hr>Hello, world!<br><hr>\n";
print "</body></html>\n";

