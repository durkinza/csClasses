/*
 * @(#)miscdefs_md.h	1.5 00/02/02
 *
 * Copyright 1995-2000 Sun Microsystems, Inc. All Rights Reserved.
 * 
 * This software is the proprietary information of Sun Microsystems, Inc.  
 * Use is subject to license terms.
 * 
 */

#ifndef _JAVASOFT_WIN32_MISCDEFS_MD_H_
#define _JAVASOFT_WIN32_MISCDEFS_MD_H_

/*
 * Override Macros definitions here for your platform specific architecture.
 * We define this to do nothing.
 */

#endif /* !_JAVASOFT_WIN32_MISCDEFS_MD_H_ */
